# Face detector

This face detector is adapted from `https://github.com/cs-giung/face-detection-pytorch`.
